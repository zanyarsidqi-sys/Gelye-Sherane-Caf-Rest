# Upgrade 827 — Revalidate: permission wrapper

Section: table_orders

Type: carried_forward_regression

Verification: static source contract assertion passed. Not a Flutter runtime or Supabase integration test.
