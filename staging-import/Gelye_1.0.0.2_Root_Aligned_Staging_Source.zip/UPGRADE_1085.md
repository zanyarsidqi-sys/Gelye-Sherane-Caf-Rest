# Upgrade 1085 — websites_management

Source-level acceptance checkpoint: dedicated Dart file exists; section is registered; SectionShell gates its content using the matching section ID. Passed. Runtime permissions and workflows not verified.
