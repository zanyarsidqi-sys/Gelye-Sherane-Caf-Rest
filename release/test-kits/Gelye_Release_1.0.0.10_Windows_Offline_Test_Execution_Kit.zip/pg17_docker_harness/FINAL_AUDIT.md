# Final offline harness review — Release 1.0.0.10

**Status: HOLD. No Supabase staging or production connections.**

## Corrections
1. Wrapped mock JWT `set_config(..., true)` smoke assertions in an explicit transaction; outside a transaction they reset at statement boundaries.
2. Corrected inactive-manager denial expectation: approval checks Tables Edit first, so a role denied by `gs_can_access` fails at that check, not the subsequent role check. A distinct test of an inactive user with a permission row is retained.
3. Asserted RLS test has a nonempty source fixture before switching roles.
4. Replaced blind 1-second concurrency startup delay with a readiness check for the active `pg_sleep(4)` hold point. Still subject to scheduling and should be verified in Docker.
5. Asserted all five synthetic employee profiles are present before behavioral tests.

## Checks actually run
- PASS: 20 numbered cases
- PASS: shell parse
- PASS: smoke JWT settings in transaction
- PASS: negative case 04 follows permission-first behavior
- PASS: RLS fixture nonempty asserted
- PASS: concurrency readiness barrier
- PASS: fixture completeness asserted

## Remaining limitations
- No PostgreSQL server, psql or Docker available: **zero SQL compilation, RLS, integration or concurrency tests actually executed**.
- The harness uses local auth mocks; it cannot establish real JWT signature verification or Supabase policy equivalence.
- `SECURITY DEFINER` runs with privileged ownership in the local harness; confirm owner and default ACL behavior in disposable PostgreSQL 17 before any staging approval.
- Existing migration chain is a reviewed alternative, not a replay of original 018/020 migration history.
- Concurrency test verifies a lock timeout and rollback scenario, not two successful concurrent commits.
- A syntax-level SQL parse was not available; the shell syntax check does not validate PostgreSQL SQL.

## Run only with local Docker Desktop
```
docker compose config
docker compose up -d --wait
docker compose exec -T postgres sh /harness/sql/10_compile.sh
docker compose down -v
```
Never substitute a Supabase connection string. Treat any test failure as a release blocker.
