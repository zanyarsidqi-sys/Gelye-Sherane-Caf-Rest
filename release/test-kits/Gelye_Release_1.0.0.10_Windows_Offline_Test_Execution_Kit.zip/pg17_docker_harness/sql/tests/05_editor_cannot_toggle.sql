-- T05: editor_cannot_toggle
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000002',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
BEGIN PERFORM public.gs_update_cafe_table(1,true,2,true); RAISE EXCEPTION 'Unexpected success'; EXCEPTION WHEN OTHERS THEN IF SQLERRM NOT LIKE '%Use Admin/Manager approval RPC%' THEN RAISE; END IF; END;
END $test$;
ROLLBACK;
