-- T09: motel_tourism_price
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000005',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
v:=public.gs_create_order_for_destination('room-1',true,false,1,1,NULL); IF NOT EXISTS(SELECT 1 FROM public.gs_order_items WHERE order_id=v AND unit_price_iqd=1500) THEN RAISE EXCEPTION 'Incorrect motel price'; END IF;
END $test$;
ROLLBACK;
