-- T16: direct_dml_denied
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000002',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
IF has_table_privilege('authenticated','public.gs_orders','INSERT') OR has_table_privilege('authenticated','public.gs_tourism_mode_approvals','INSERT') THEN RAISE EXCEPTION 'Direct DML allowed'; END IF;
END $test$;
ROLLBACK;
