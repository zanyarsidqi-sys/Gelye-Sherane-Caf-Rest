-- T02: aal1_approval_denied
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal1"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
BEGIN PERFORM public.gs_approve_tourism_mode(1,true,'Manager approves'); RAISE EXCEPTION 'Unexpected success'; EXCEPTION WHEN OTHERS THEN IF SQLERRM NOT LIKE '%MFA AAL2 required%' THEN RAISE; END IF; END;
END $test$;
ROLLBACK;
