-- T15: cross_section_rls
BEGIN;
-- Insert a real cafe order as local owner; transaction rollback removes it.
INSERT INTO public.gs_orders(created_by,destination,is_motel,tourism_mode) VALUES ('00000000-0000-0000-0000-000000000002','1',false,false);
DO $$ BEGIN IF (SELECT count(*) FROM public.gs_orders WHERE is_motel=false) < 1 THEN RAISE EXCEPTION 'Missing fixture order'; END IF; END $$;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000005',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
IF current_user <> 'authenticated' THEN RAISE EXCEPTION 'Wrong role'; END IF; IF EXISTS(SELECT 1 FROM public.gs_orders WHERE is_motel=false) THEN RAISE EXCEPTION 'Cross section order leaked'; END IF;
END $test$;
ROLLBACK;
