-- T10: missing_section_denied
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000004',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
BEGIN PERFORM public.gs_create_order_for_destination('1',false,false,1,1,1); RAISE EXCEPTION 'Unexpected success'; EXCEPTION WHEN OTHERS THEN IF SQLERRM NOT LIKE '%Not authorized%' THEN RAISE; END IF; END;
END $test$;
ROLLBACK;
