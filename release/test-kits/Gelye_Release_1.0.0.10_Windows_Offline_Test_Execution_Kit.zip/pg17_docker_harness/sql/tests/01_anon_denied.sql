-- T01: anon_denied
BEGIN;
SET LOCAL ROLE anon;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
IF has_table_privilege('anon','public.gs_orders','SELECT') THEN RAISE EXCEPTION 'anon SELECT'; END IF; BEGIN PERFORM public.gs_create_cart_order('1',false,1,'[{"product_id":1,"quantity":1}]'::jsonb); RAISE EXCEPTION 'Unexpected authorization success'; EXCEPTION WHEN insufficient_privilege THEN NULL; WHEN OTHERS THEN RAISE; END;
END $test$;
ROLLBACK;
