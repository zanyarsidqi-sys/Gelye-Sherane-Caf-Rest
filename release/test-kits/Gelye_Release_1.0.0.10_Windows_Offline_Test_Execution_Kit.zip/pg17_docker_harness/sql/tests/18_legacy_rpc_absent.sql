-- T18: legacy_rpc_absent
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
IF to_regprocedure('public.gs_create_order(text,boolean,boolean,bigint,integer)') IS NOT NULL THEN RAISE EXCEPTION 'Legacy bypass present'; END IF;
END $test$;
ROLLBACK;
