-- T03: aal1_order_denied
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000002',true);
SELECT set_config('request.jwt.claims','{"aal":"aal1"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
BEGIN PERFORM public.gs_create_order_for_destination('1',false,true,1,1,1); RAISE EXCEPTION 'Unexpected success'; EXCEPTION WHEN OTHERS THEN IF SQLERRM NOT LIKE '%MFA required%' THEN RAISE; END IF; END;
END $test$;
ROLLBACK;
