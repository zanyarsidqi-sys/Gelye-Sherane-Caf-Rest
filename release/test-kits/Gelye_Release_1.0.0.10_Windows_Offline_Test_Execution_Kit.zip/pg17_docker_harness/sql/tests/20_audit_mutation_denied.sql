-- T20: audit_mutation_denied
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
IF has_table_privilege('authenticated','public.gs_tourism_mode_approvals','INSERT') OR has_table_privilege('authenticated','public.gs_tourism_mode_approvals','UPDATE') OR has_table_privilege('authenticated','public.gs_tourism_mode_approvals','DELETE') THEN RAISE EXCEPTION 'Audit mutation grant'; END IF;
END $test$;
ROLLBACK;
