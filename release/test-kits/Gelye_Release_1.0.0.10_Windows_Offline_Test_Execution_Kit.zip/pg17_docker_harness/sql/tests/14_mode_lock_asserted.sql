-- T14: mode_lock_asserted
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname='gs_approve_tourism_mode' AND pg_get_functiondef(oid) LIKE '%FOR UPDATE%') THEN RAISE EXCEPTION 'Approval missing row lock'; END IF;
END $test$;
ROLLBACK;
