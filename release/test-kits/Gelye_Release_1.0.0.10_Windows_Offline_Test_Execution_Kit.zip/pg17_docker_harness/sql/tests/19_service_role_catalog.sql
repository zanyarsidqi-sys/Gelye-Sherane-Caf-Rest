-- T19: service_role_catalog
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
IF NOT has_table_privilege('service_role','public.gs_menu_products','INSERT') THEN RAISE EXCEPTION 'Service role cannot provision'; END IF;
END $test$;
ROLLBACK;
