-- T11: cart_atomic_snapshot
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000002',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
v:=public.gs_create_cart_order('ignored',false,1,'[{"product_id":1,"quantity":2}]'::jsonb); IF (SELECT count(*) FROM public.gs_order_items WHERE order_id=v AND unit_price_iqd=1000 AND line_total_iqd=2000)<>1 THEN RAISE EXCEPTION 'Bad cart snapshot'; END IF;
END $test$;
ROLLBACK;
