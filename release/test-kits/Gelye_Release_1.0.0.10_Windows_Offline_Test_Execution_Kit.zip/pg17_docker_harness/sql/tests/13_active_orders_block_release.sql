-- T13: active_orders_block_release
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
v:=public.gs_create_order_for_destination('1',false,false,1,1,1); BEGIN PERFORM public.gs_update_cafe_table(1,false,0,false); RAISE EXCEPTION 'Unexpected success'; EXCEPTION WHEN OTHERS THEN IF SQLERRM NOT LIKE '%Active orders block release%' THEN RAISE; END IF; END;
END $test$;
ROLLBACK;
