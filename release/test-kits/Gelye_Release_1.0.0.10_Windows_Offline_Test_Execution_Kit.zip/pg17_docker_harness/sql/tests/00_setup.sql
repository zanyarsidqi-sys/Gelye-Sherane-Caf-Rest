-- Synthetic identities only. Runs as local postgres owner.
INSERT INTO auth.users(id) VALUES
('00000000-0000-0000-0000-000000000004'),('00000000-0000-0000-0000-000000000005');
INSERT INTO public.employee_profiles(user_id,role,is_active) VALUES
('00000000-0000-0000-0000-000000000004','admin',true),
('00000000-0000-0000-0000-000000000005','employee',true);
INSERT INTO public.employee_section_permissions(user_id,section_key,can_view,can_create,can_edit) VALUES
('00000000-0000-0000-0000-000000000004','tables',true,false,false),
('00000000-0000-0000-0000-000000000005','motel_orders',true,true,false),
('00000000-0000-0000-0000-000000000001','motel_orders',true,true,false),
('00000000-0000-0000-0000-000000000005','menu',true,false,false);


DO $$ BEGIN IF (SELECT count(*) FROM public.employee_profiles WHERE user_id IN ('00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002','00000000-0000-0000-0000-000000000003','00000000-0000-0000-0000-000000000004','00000000-0000-0000-0000-000000000005'))<>5 THEN RAISE EXCEPTION 'Synthetic fixture identities incomplete'; END IF; END $$;
