-- T12: duplicate_cart_rejected
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000002',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
BEGIN PERFORM public.gs_create_cart_order('ignored',false,1,'[{"product_id":1,"quantity":1},{"product_id":1,"quantity":2}]'::jsonb); RAISE EXCEPTION 'Unexpected success'; EXCEPTION WHEN OTHERS THEN IF SQLERRM NOT LIKE '%Invalid or duplicate item%' THEN RAISE; END IF; END;
END $test$;
ROLLBACK;
