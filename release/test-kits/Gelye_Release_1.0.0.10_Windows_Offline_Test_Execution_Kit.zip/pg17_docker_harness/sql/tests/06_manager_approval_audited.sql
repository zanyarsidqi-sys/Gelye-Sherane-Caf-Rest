-- T06: manager_approval_audited
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
v:=public.gs_approve_tourism_mode(1,true,'Manager approves'); IF NOT EXISTS(SELECT 1 FROM public.gs_tourism_mode_approvals WHERE id=v AND approved_by=auth.uid() AND previous_mode=false AND approved_mode=true) THEN RAISE EXCEPTION 'Audit absent'; END IF;
END $test$;
ROLLBACK;
