-- T17: anon_sequence_denied
BEGIN;
SET LOCAL ROLE anon;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $test$ DECLARE v bigint; n bigint; BEGIN
IF has_sequence_privilege('anon','public.gs_orders_id_seq','USAGE') THEN RAISE EXCEPTION 'Anon sequence access'; END IF;
END $test$;
ROLLBACK;
