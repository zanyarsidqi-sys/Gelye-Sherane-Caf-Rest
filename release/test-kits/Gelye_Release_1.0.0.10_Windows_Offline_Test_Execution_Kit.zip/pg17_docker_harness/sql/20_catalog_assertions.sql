-- Stop immediately on failed assertions.
DO $$ DECLARE n int; BEGIN
 SELECT count(*) INTO n FROM pg_proc p JOIN pg_namespace ns ON ns.oid=p.pronamespace
 WHERE ns.nspname='public' AND p.proname IN ('gs_can_access','gs_create_cart_order','gs_create_order_for_destination','gs_update_cafe_table','gs_approve_tourism_mode')
 AND p.prosecdef AND 'search_path='=ANY(p.proconfig);
 IF n<>5 THEN RAISE EXCEPTION 'Expected five hardened SECURITY DEFINER functions, found %',n; END IF;
 IF EXISTS(SELECT 1 FROM pg_proc p JOIN pg_namespace ns ON ns.oid=p.pronamespace
  WHERE ns.nspname='public' AND p.proname LIKE 'gs_%' AND has_function_privilege('anon',p.oid,'EXECUTE'))
 THEN RAISE EXCEPTION 'Anon can execute gs function'; END IF;
 IF EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace ns ON ns.oid=c.relnamespace
 WHERE ns.nspname='public' AND c.relname LIKE 'gs_%' AND c.relkind='r'
 AND (has_table_privilege('authenticated',c.oid,'INSERT') OR has_table_privilege('anon',c.oid,'SELECT')))
 THEN RAISE EXCEPTION 'Unsafe table grants'; END IF;
 IF EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace ns ON ns.oid=c.relnamespace
 WHERE ns.nspname='public' AND c.relname LIKE 'gs_%' AND c.relkind='S'
 AND has_sequence_privilege('anon',c.oid,'USAGE'))
 THEN RAISE EXCEPTION 'Unsafe sequence grants'; END IF;
IF EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace ns ON ns.oid=p.pronamespace
 WHERE ns.nspname='public' AND p.proname LIKE 'gs_%'
 AND pg_get_userbyid(p.proowner) <> 'postgres')
 THEN RAISE EXCEPTION 'Unexpected function owner'; END IF;
 IF has_table_privilege('authenticated','public.gs_tourism_mode_approvals','INSERT')
 OR has_table_privilege('authenticated','public.gs_tourism_mode_approvals','UPDATE')
 THEN RAISE EXCEPTION 'Audit DML exposed'; END IF;
END $$;
