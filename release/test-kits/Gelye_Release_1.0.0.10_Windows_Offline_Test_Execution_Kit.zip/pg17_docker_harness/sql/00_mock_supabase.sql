-- LOCAL-ONLY Supabase auth emulation. Never apply to real Supabase.
CREATE ROLE anon NOLOGIN;
CREATE ROLE authenticated NOLOGIN;
CREATE ROLE service_role NOLOGIN BYPASSRLS;
CREATE SCHEMA auth;
CREATE TABLE auth.users(id uuid PRIMARY KEY);
CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
 SELECT nullif(current_setting('request.jwt.claim.sub', true),'')::uuid
$$;
CREATE FUNCTION auth.jwt() RETURNS jsonb LANGUAGE sql STABLE AS $$
 SELECT coalesce(nullif(current_setting('request.jwt.claims',true),''),'{}')::jsonb
$$;
GRANT USAGE ON SCHEMA auth, public TO authenticated, anon;
CREATE TABLE public.employee_profiles(
 user_id uuid PRIMARY KEY REFERENCES auth.users(id),
 full_name text NOT NULL DEFAULT '',
 role text NOT NULL CHECK (role IN ('admin','manager','employee')),
 is_active boolean NOT NULL DEFAULT false
);
CREATE TABLE public.employee_section_permissions(
 user_id uuid NOT NULL REFERENCES public.employee_profiles(user_id),
 section_key text NOT NULL,
 can_view boolean NOT NULL DEFAULT false,
 can_create boolean NOT NULL DEFAULT false,
 can_edit boolean NOT NULL DEFAULT false,
 can_delete boolean NOT NULL DEFAULT false,
 PRIMARY KEY(user_id,section_key)
);
ALTER TABLE public.employee_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_section_permissions ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.employee_profiles,public.employee_section_permissions FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.employee_profiles,public.employee_section_permissions TO authenticated;
CREATE POLICY ep_self ON public.employee_profiles FOR SELECT TO authenticated USING (auth.uid()=user_id);
CREATE POLICY ep_aal2 ON public.employee_profiles AS RESTRICTIVE FOR SELECT TO authenticated USING (auth.jwt()->>'aal'='aal2');
CREATE POLICY perm_self ON public.employee_section_permissions FOR SELECT TO authenticated USING (auth.uid()=user_id);
CREATE POLICY perm_aal2 ON public.employee_section_permissions AS RESTRICTIVE FOR SELECT TO authenticated USING (auth.jwt()->>'aal'='aal2');
