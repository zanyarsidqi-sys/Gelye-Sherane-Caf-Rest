-- Controlled synthetic test identities. Never use real customer data.
INSERT INTO auth.users(id) VALUES
 ('00000000-0000-0000-0000-000000000001'),
 ('00000000-0000-0000-0000-000000000002'),
 ('00000000-0000-0000-0000-000000000003');
INSERT INTO public.employee_profiles(user_id,role,is_active) VALUES
 ('00000000-0000-0000-0000-000000000001','manager',true),
 ('00000000-0000-0000-0000-000000000002','employee',true),
 ('00000000-0000-0000-0000-000000000003','manager',false);
INSERT INTO public.employee_section_permissions(user_id,section_key,can_view,can_create,can_edit) VALUES
 ('00000000-0000-0000-0000-000000000001','tables',true,false,true),
 ('00000000-0000-0000-0000-000000000001','table_orders',true,true,false),
 ('00000000-0000-0000-0000-000000000002','tables',true,false,true),
 ('00000000-0000-0000-0000-000000000002','table_orders',true,true,false),
 ('00000000-0000-0000-0000-000000000003','tables',true,false,true);
INSERT INTO public.gs_cafe_tables(table_number,occupied,guests) VALUES(1,true,2);
INSERT INTO public.gs_menu_products(barcode,name,normal_price_iqd,tourism_price_iqd) VALUES('X1','Test',1000,1500);
-- Each session is a local stand-in for a verified JWT. SET ROLE does not validate real tokens.
BEGIN;
DO $$ BEGIN
 PERFORM set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
 PERFORM set_config('request.jwt.claims','{"aal":"aal1"}',true);
 IF public.gs_can_access('tables','can_edit') THEN RAISE EXCEPTION 'AAL1 was permitted'; END IF;
 PERFORM set_config('request.jwt.claims','{"aal":"aal2"}',true);
 IF NOT public.gs_can_access('tables','can_edit') THEN RAISE EXCEPTION 'AAL2 manager denied'; END IF;
 PERFORM set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000003',true);
 IF public.gs_can_access('tables','can_edit') THEN RAISE EXCEPTION 'Inactive manager permitted'; END IF;
END $$;
ROLLBACK;
-- For real role-level behavior tests, use SET ROLE authenticated in a separate
-- session with matching JWT GUCs; DO above runs as owner and is only a smoke test.

-- Verify under authenticated role rather than owner (mocked JWT claims only).
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $$ BEGIN
 IF NOT public.gs_can_access('tables','can_edit') THEN RAISE EXCEPTION 'AAL2 manager denied under authenticated role'; END IF;
END $$;
SELECT set_config('request.jwt.claims','{"aal":"aal1"}',true);
DO $$ BEGIN
 IF public.gs_can_access('tables','can_edit') THEN RAISE EXCEPTION 'AAL1 allowed under authenticated role'; END IF;
END $$;
ROLLBACK;
