#!/bin/sh
set -eu
export PGPASSWORD="${POSTGRES_PASSWORD:-local_test_only}"
P="psql -X -U postgres -d cafe_test -v ON_ERROR_STOP=1"
# Session A creates a real table order and holds the row lock until rollback.
$P <<'SQL' >/tmp/pg17_order_a.log 2>&1 &
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000002',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
SELECT public.gs_create_order_for_destination('ignored',false,true,1,1,1);
SELECT pg_sleep(4);
ROLLBACK;
SQL
PID=$!
# Wait for session A to reach its hold point rather than assuming a fixed startup time.
ready=0
i=0
while [ "$i" -lt 40 ]; do
  if $P -Atc "SELECT EXISTS (SELECT 1 FROM pg_stat_activity WHERE datname='cafe_test' AND query LIKE '%SELECT pg_sleep(4)%' AND state='active')" | grep -qx t; then
    ready=1
    break
  fi
  if ! kill -0 "$PID" 2>/dev/null; then cat /tmp/pg17_order_a.log; echo 'FAIL: order session ended early'; exit 1; fi
  sleep 0.1
  i=$((i+1))
done
[ "$ready" -eq 1 ] || { cat /tmp/pg17_order_a.log; echo 'FAIL: order session never reached hold point'; wait "$PID" || :; exit 1; }
# Session B tries manager approval. It must wait for the same table lock.
if $P <<'SQL' >/tmp/pg17_approval_b.log 2>&1; then
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
SET LOCAL statement_timeout='1000ms';
SELECT public.gs_approve_tourism_mode(1,true,'Concurrency approval');
ROLLBACK;
SQL
 echo 'FAIL: approval bypassed order lock'; wait "$PID"; exit 1
fi
if ! grep -q 'canceling statement due to statement timeout' /tmp/pg17_approval_b.log; then
 cat /tmp/pg17_approval_b.log; wait "$PID"; exit 1
fi
wait "$PID"
# After the first transaction rolls back, the approval must succeed and audit atomically.
$P <<'SQL'
BEGIN;
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','00000000-0000-0000-0000-000000000001',true);
SELECT set_config('request.jwt.claims','{"aal":"aal2"}',true);
DO $$ DECLARE v bigint; BEGIN
 v:=public.gs_approve_tourism_mode(1,true,'Concurrency approval');
 IF NOT EXISTS (SELECT 1 FROM public.gs_tourism_mode_approvals
   WHERE id=v AND approved_mode=true) THEN RAISE EXCEPTION 'Missing approval audit'; END IF;
END $$;
ROLLBACK;
SQL
echo 'PASS: order-versus-approval lock, timeout and atomic audit (local emulation)'
