#!/bin/sh
set -eu
export PGPASSWORD="${POSTGRES_PASSWORD:-local_test_only}"
PSQL="psql -U postgres -d cafe_test -X -v ON_ERROR_STOP=1"
$PSQL -f /harness/sql/00_mock_supabase.sql
for f in /harness/migrations/*.sql; do echo "COMPILING: $f"; $PSQL -f "$f"; done
$PSQL -f /harness/sql/20_catalog_assertions.sql
$PSQL -f /harness/sql/30_behavior_tests.sql
$PSQL -f /harness/sql/tests/00_setup.sql
count=0
for f in /harness/sql/tests/[0-9][0-9]_*.sql; do
 [ "${f##*/}" = "00_setup.sql" ] && continue
 echo "RUNNING: $f"; $PSQL -f "$f"; count=$((count+1))
done
[ "$count" -eq 20 ] || { echo "Expected 20 cases, found $count"; exit 1; }
sh /harness/sql/40_concurrency.sh
