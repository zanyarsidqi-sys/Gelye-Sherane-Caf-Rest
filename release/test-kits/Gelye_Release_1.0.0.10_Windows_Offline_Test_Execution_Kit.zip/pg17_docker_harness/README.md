# Gelye Sherane Release 1.0.0.10 — Windows Docker Desktop offline harness

**Offline local testing only.** Never run the SQL against Supabase. This harness uses synthetic auth/JWT claims; it cannot validate real Supabase authentication.

## Windows instructions (PowerShell + VS Code)

1. Install Docker Desktop for Windows, enable WSL 2 engine, and start Docker Desktop. Confirm Docker Engine is running with `docker version`.
2. Extract this ZIP into a folder such as `C:\Work\GelyeCafePg17Test`. Open the extracted `pg17_docker_harness` folder in VS Code (File → Open Folder).
3. Open Terminal → New Terminal, select **PowerShell**, and ensure the terminal is in the folder containing `compose.yaml`.
4. Run `docker compose config` to inspect the configuration. The only published port is bound to `127.0.0.1:55432` and the test database lives on ephemeral tmpfs.
5. Run `docker compose up -d --wait`. If image pull needs internet, allow Docker to download `postgres:17.6` first; after download, tests use no Supabase or remote DB.
6. Run `docker compose exec -T postgres sh /harness/sql/10_compile.sh`.
7. A zero exit code means the **included assertions** passed. It does **not** mean all 20 security and concurrency cases were tested. Inspect errors carefully.
8. Run `docker compose down -v` to discard the local database.

To start fresh after a failed run: `docker compose down -v` then `docker compose up -d --wait`. Do not rerun the compilation script against an already migrated container because it intentionally uses CREATE statements.

## Scope and limitations

- Docker-only `psql` invocation fixes the earlier broken host-side path and `PSQL` command-string handling.
- SQL files compile in lexical filename order: 001,016,017,018,019,020,021.
- 018 and 020 are no-op compatibility markers, not copies of historical upstream migrations.
- Tests include catalog SECURITY DEFINER/search_path, function ownership, anonymous execute, table/sequence grants, and smoke checks for AAL1/AAL2 including `SET ROLE authenticated`.
- The SQL mocks `auth.uid()` and `auth.jwt()` with session variables. These variables can be forged locally; never treat mock test success as real JWT validation.
- The behavior suite is **not a full 20-case test implementation**. In particular, concurrent sessions, RLS cross-user isolation, order creation/rollback, mode-approval auditing, and price race conditions require more tests.
- The Docker image tag is PostgreSQL 17.6, not the Supabase 17.11 patch. Major version is 17; minor patch differences are untested.
- Docker and PostgreSQL were not available in the assistant environment; **no actual execution or SQL compilation was performed**.

## Concurrency manual procedure

Use two VS Code terminals. Start `docker compose exec postgres psql -U postgres -d cafe_test` in each. Before testing, seed a new table and product and create synthetic users. In each session set role `authenticated` and synthetic claim GUCs. In session A, `BEGIN; SELECT public.gs_create_cart_order('',false,1,'[{"product_id":1,"quantity":1}]'::jsonb);` and keep the transaction open. In session B, `SET statement_timeout='2s'; SELECT public.gs_approve_tourism_mode(1,true,'Manager approved');` — it should block then time out while A holds the table lock. After A commits, B can retry if no active orders remain. This procedure is documentation only and has **not** been executed.


## Expanded test suite (20 cases + concurrent lock)
`sh /harness/sql/10_compile.sh` now runs `sql/tests/01_*.sql` through `20_*.sql` after seeding synthetic identities. Each role test uses `SET LOCAL ROLE` and mock JWT GUCs in a rolled-back transaction. `40_concurrency.sh` uses two independent psql sessions and a deliberate lock timeout. **T14 is a lock-serialization assertion, not a full order-vs-approval race simulation.** This is a local mock, not proof of Supabase JWT verification. Do not run this twice on the same volume without resetting (`docker compose down -v`).
