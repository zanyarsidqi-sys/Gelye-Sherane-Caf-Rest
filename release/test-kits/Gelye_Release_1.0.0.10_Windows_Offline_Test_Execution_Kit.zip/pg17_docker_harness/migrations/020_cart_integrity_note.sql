-- Integrity controls are integrated into 019_cart_rpc.sql; no unsafe overwrite.
SELECT 1 WHERE FALSE;
