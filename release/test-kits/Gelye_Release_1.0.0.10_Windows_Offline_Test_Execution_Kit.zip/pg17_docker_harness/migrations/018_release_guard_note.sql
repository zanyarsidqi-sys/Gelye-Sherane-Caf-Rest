-- Dependency marker only. Guarded table updates are installed by 021 approval.
-- Do not install upstream 018 unmodified; it allows Tables Edit to change Tourism Mode.
SELECT 1 WHERE FALSE;
