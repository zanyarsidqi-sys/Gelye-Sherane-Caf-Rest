-- REVIEW ONLY. Run after 001.
BEGIN;
CREATE TABLE public.gs_cafe_tables (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 table_number integer NOT NULL UNIQUE CHECK(table_number>0),
 capacity integer NOT NULL DEFAULT 4 CHECK(capacity BETWEEN 1 AND 50),
 occupied boolean NOT NULL DEFAULT false,
 guests integer NOT NULL DEFAULT 0 CHECK(guests BETWEEN 0 AND 50),
 tourism_mode boolean NOT NULL DEFAULT false,
 updated_at timestamptz NOT NULL DEFAULT now(),
 updated_by uuid REFERENCES auth.users(id),
 CONSTRAINT gs_table_empty_reset CHECK(occupied OR (guests=0 AND tourism_mode=false)),
 CONSTRAINT gs_table_guests CHECK(NOT occupied OR guests>0)
);
ALTER TABLE public.gs_cafe_tables ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.gs_cafe_tables FROM PUBLIC,anon,authenticated;
GRANT SELECT ON public.gs_cafe_tables TO authenticated;
GRANT ALL ON public.gs_cafe_tables TO service_role;
REVOKE ALL ON SEQUENCE public.gs_cafe_tables_id_seq FROM PUBLIC,anon,authenticated;
GRANT USAGE,SELECT ON SEQUENCE public.gs_cafe_tables_id_seq TO service_role;
CREATE POLICY gs_cafe_tables_read ON public.gs_cafe_tables FOR SELECT TO authenticated
 USING (public.gs_can_access('tables','can_view'));
COMMIT;
