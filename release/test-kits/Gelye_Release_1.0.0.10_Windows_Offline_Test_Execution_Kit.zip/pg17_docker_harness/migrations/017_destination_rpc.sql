BEGIN;
CREATE FUNCTION public.gs_create_order_for_destination(
 p_destination text,p_is_motel boolean,p_tourism_mode boolean,
 p_product_id bigint,p_quantity integer,p_table_number integer DEFAULT NULL)
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_uid uuid:=auth.uid(); v_mode boolean; v_price bigint; v_order bigint;
BEGIN
 IF v_uid IS NULL OR auth.jwt()->>'aal' IS DISTINCT FROM 'aal2' THEN RAISE EXCEPTION 'MFA required'; END IF;
 IF p_is_motel IS NULL OR p_product_id IS NULL OR p_product_id<=0
    OR p_quantity IS NULL OR p_quantity NOT BETWEEN 1 AND 999 THEN RAISE EXCEPTION 'Invalid order'; END IF;
 IF NOT public.gs_can_access(CASE WHEN p_is_motel THEN 'motel_orders' ELSE 'table_orders' END,'can_create')
 THEN RAISE EXCEPTION 'Not authorized'; END IF;
 IF p_is_motel THEN
   IF p_table_number IS NOT NULL OR p_destination IS NULL OR length(btrim(p_destination)) NOT BETWEEN 1 AND 120
   THEN RAISE EXCEPTION 'Invalid motel destination'; END IF;
   v_mode:=true;
 ELSE
   IF p_table_number IS NULL OR p_table_number<=0 THEN RAISE EXCEPTION 'Table required'; END IF;
   SELECT tourism_mode INTO v_mode FROM public.gs_cafe_tables
    WHERE table_number=p_table_number AND occupied=true FOR UPDATE;
   IF NOT FOUND THEN RAISE EXCEPTION 'Table unavailable'; END IF;
 END IF;
 SELECT CASE WHEN v_mode THEN tourism_price_iqd ELSE normal_price_iqd END INTO v_price
  FROM public.gs_menu_products WHERE id=p_product_id AND is_active=true;
 IF NOT FOUND OR v_price IS NULL OR v_price<0 OR v_price>9000000000000/ p_quantity
 THEN RAISE EXCEPTION 'Invalid product or price'; END IF;
 INSERT INTO public.gs_orders(created_by,destination,is_motel,tourism_mode)
 VALUES(v_uid,CASE WHEN p_is_motel THEN btrim(p_destination) ELSE p_table_number::text END,p_is_motel,v_mode)
 RETURNING id INTO v_order;
 INSERT INTO public.gs_order_items(order_id,product_id,quantity,unit_price_iqd)
 VALUES(v_order,p_product_id,p_quantity,v_price);
 RETURN v_order;
END $$;
REVOKE ALL ON FUNCTION public.gs_create_order_for_destination(text,boolean,boolean,bigint,integer,integer) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.gs_create_order_for_destination(text,boolean,boolean,bigint,integer,integer) TO authenticated;
COMMIT;
