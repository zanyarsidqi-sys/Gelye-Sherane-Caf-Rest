-- Release 1.0.0.10: staging-only Tourism approval hardening.
-- REVIEW CANDIDATE. NOT EXECUTED.
-- Apply ONLY after audited dependencies 001,016,017,018,019,020.
-- Approval is one-step; requested_by and approved_by are the same manager/admin.
-- Target project: snypqykxtevmgxlrivro; NEVER production.
BEGIN;
CREATE TABLE public.gs_tourism_mode_approvals (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 table_number integer NOT NULL REFERENCES public.gs_cafe_tables(table_number),
 requested_by uuid NOT NULL REFERENCES auth.users(id),
 approved_by uuid NOT NULL REFERENCES auth.users(id),
 previous_mode boolean NOT NULL,
 approved_mode boolean NOT NULL,
 reason text NOT NULL CHECK (length(btrim(reason)) BETWEEN 5 AND 500),
 approved_at timestamptz NOT NULL DEFAULT now(),
 CONSTRAINT gs_tourism_approval_change CHECK (previous_mode IS DISTINCT FROM approved_mode)
);
ALTER TABLE public.gs_tourism_mode_approvals ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.gs_tourism_mode_approvals FROM PUBLIC,anon,authenticated;
GRANT ALL ON public.gs_tourism_mode_approvals TO service_role;
REVOKE ALL ON SEQUENCE public.gs_tourism_mode_approvals_id_seq FROM PUBLIC,anon,authenticated;
GRANT USAGE,SELECT ON SEQUENCE public.gs_tourism_mode_approvals_id_seq TO service_role;
GRANT SELECT ON public.gs_tourism_mode_approvals TO authenticated;
CREATE POLICY gs_tourism_approvals_read ON public.gs_tourism_mode_approvals
 FOR SELECT TO authenticated USING (
   auth.uid() IS NOT NULL
   AND auth.jwt()->>'aal' = 'aal2'
   AND public.gs_can_access('tables','can_view')
 );
-- Authorization must be enforced inside SECURITY DEFINER even if table RLS is bypassed.
CREATE OR REPLACE FUNCTION public.gs_approve_tourism_mode(
 p_table_number integer, p_new_mode boolean, p_reason text)
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_uid uuid := auth.uid(); v_role text; v_old boolean;
 v_occupied boolean; v_id bigint;
BEGIN
 IF v_uid IS NULL OR auth.jwt()->>'aal' IS DISTINCT FROM 'aal2' THEN
   RAISE EXCEPTION 'MFA AAL2 required';
 END IF;
 IF NOT public.gs_can_access('tables','can_edit') THEN
   RAISE EXCEPTION 'Tables edit permission required';
 END IF;
 SELECT role INTO v_role FROM public.employee_profiles
  WHERE user_id=v_uid AND is_active=true;
 IF v_role IS NULL OR v_role NOT IN ('admin','manager') THEN
   RAISE EXCEPTION 'Admin/Manager approval required';
 END IF;
 IF p_new_mode IS NULL OR p_reason IS NULL OR length(btrim(p_reason)) NOT BETWEEN 5 AND 500 THEN
   RAISE EXCEPTION 'Invalid approval details';
 END IF;
 SELECT tourism_mode, occupied INTO v_old,v_occupied FROM public.gs_cafe_tables
  WHERE table_number=p_table_number FOR UPDATE;
 IF NOT FOUND OR NOT v_occupied THEN RAISE EXCEPTION 'Occupied table required'; END IF;
 IF v_old IS NOT DISTINCT FROM p_new_mode THEN RAISE EXCEPTION 'No mode change'; END IF;
 IF EXISTS (SELECT 1 FROM public.gs_orders
  WHERE is_motel=false AND destination=p_table_number::text
  AND status IN ('new','preparing','ready')) THEN
   RAISE EXCEPTION 'Active orders block mode change';
 END IF;
 UPDATE public.gs_cafe_tables SET tourism_mode=p_new_mode, updated_at=now(), updated_by=v_uid
  WHERE table_number=p_table_number;
 INSERT INTO public.gs_tourism_mode_approvals
  (table_number,requested_by,approved_by,previous_mode,approved_mode,reason)
 VALUES(p_table_number,v_uid,v_uid,v_old,p_new_mode,btrim(p_reason)) RETURNING id INTO v_id;
 RETURN v_id;
END $$;
REVOKE ALL ON FUNCTION public.gs_approve_tourism_mode(integer,boolean,text) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.gs_approve_tourism_mode(integer,boolean,text) TO authenticated;

-- Replace 018 table update RPC: non-approvers cannot change mode.
CREATE OR REPLACE FUNCTION public.gs_update_cafe_table(
 p_table_number integer,p_occupied boolean,p_guests integer,p_tourism boolean)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_uid uuid:=auth.uid(); v_capacity integer; v_was_occupied boolean;
 v_previous_tourism boolean;
BEGIN
 IF v_uid IS NULL OR auth.jwt()->>'aal' IS DISTINCT FROM 'aal2'
  OR NOT public.gs_can_access('tables','can_edit') THEN
  RAISE EXCEPTION 'Permission denied';
 END IF;
 IF p_occupied IS NULL OR p_tourism IS NULL THEN RAISE EXCEPTION 'Missing table state'; END IF;
 SELECT capacity,occupied,tourism_mode INTO v_capacity,v_was_occupied,v_previous_tourism
  FROM public.gs_cafe_tables WHERE table_number=p_table_number FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'Table not configured'; END IF;
 IF p_occupied AND (p_guests IS NULL OR p_guests < 1 OR p_guests > v_capacity) THEN
  RAISE EXCEPTION 'Invalid guests'; END IF;
 IF p_occupied AND p_tourism IS DISTINCT FROM v_previous_tourism THEN
  RAISE EXCEPTION 'Use Admin/Manager approval RPC to change Tourism Mode';
 END IF;
 IF v_was_occupied AND NOT p_occupied AND EXISTS (
  SELECT 1 FROM public.gs_orders WHERE is_motel=false
   AND destination=p_table_number::text AND status IN ('new','preparing','ready')
 ) THEN RAISE EXCEPTION 'Active orders block release'; END IF;
 UPDATE public.gs_cafe_tables SET occupied=p_occupied,
  guests=CASE WHEN p_occupied THEN p_guests ELSE 0 END,
  tourism_mode=CASE WHEN p_occupied THEN v_previous_tourism ELSE false END,
  updated_at=now(),updated_by=v_uid WHERE table_number=p_table_number;
END $$;
REVOKE ALL ON FUNCTION public.gs_update_cafe_table(integer,boolean,integer,boolean)
 FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.gs_update_cafe_table(integer,boolean,integer,boolean)
 TO authenticated;
COMMIT;
