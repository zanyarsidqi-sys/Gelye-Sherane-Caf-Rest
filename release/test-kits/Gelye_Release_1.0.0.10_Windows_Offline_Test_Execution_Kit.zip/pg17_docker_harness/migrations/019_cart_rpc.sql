BEGIN;
CREATE FUNCTION public.gs_create_cart_order(p_destination text,p_is_motel boolean,
 p_table_number integer,p_items jsonb)
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE v_uid uuid:=auth.uid(); v_mode boolean; v_order bigint;
 v_line jsonb; v_id bigint; v_qty integer; v_price bigint; v_seen bigint[]:=ARRAY[]::bigint[];
 v_prices bigint[]:=ARRAY[]::bigint[]; v_line_index integer:=0;
BEGIN
 IF v_uid IS NULL OR auth.jwt()->>'aal' IS DISTINCT FROM 'aal2' THEN RAISE EXCEPTION 'MFA required'; END IF;
 IF p_is_motel IS NULL OR NOT public.gs_can_access(
 CASE WHEN p_is_motel THEN 'motel_orders' ELSE 'table_orders' END,'can_create')
 THEN RAISE EXCEPTION 'Not authorized'; END IF;
 IF p_items IS NULL OR jsonb_typeof(p_items)<>'array'
  OR jsonb_array_length(p_items) NOT BETWEEN 1 AND 100 THEN RAISE EXCEPTION 'Invalid cart'; END IF;
 IF p_is_motel THEN
  IF p_table_number IS NOT NULL OR p_destination IS NULL
   OR length(btrim(p_destination)) NOT BETWEEN 1 AND 120 THEN RAISE EXCEPTION 'Invalid motel destination'; END IF;
  v_mode:=true;
 ELSE
  IF p_table_number IS NULL OR p_table_number<=0 THEN RAISE EXCEPTION 'Table required'; END IF;
  SELECT tourism_mode INTO v_mode FROM public.gs_cafe_tables
   WHERE table_number=p_table_number AND occupied=true FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Table unavailable'; END IF;
 END IF;
 FOR v_line IN SELECT value FROM jsonb_array_elements(p_items) LOOP
  IF jsonb_typeof(v_line)<>'object' OR jsonb_typeof(v_line->'product_id')<>'number'
   OR jsonb_typeof(v_line->'quantity')<>'number' THEN RAISE EXCEPTION 'Invalid item'; END IF;
  BEGIN
   v_id:=(v_line->>'product_id')::bigint; v_qty:=(v_line->>'quantity')::integer;
  EXCEPTION WHEN invalid_text_representation OR numeric_value_out_of_range THEN
   RAISE EXCEPTION 'Invalid product or quantity';
  END;
  IF v_id IS NULL OR v_id<=0 OR v_qty IS NULL OR v_qty NOT BETWEEN 1 AND 999
   OR v_id=ANY(v_seen) THEN RAISE EXCEPTION 'Invalid or duplicate item'; END IF;
  v_seen:=array_append(v_seen,v_id);
  SELECT CASE WHEN v_mode THEN tourism_price_iqd ELSE normal_price_iqd END INTO v_price
   FROM public.gs_menu_products WHERE id=v_id AND is_active=true;
  IF NOT FOUND OR v_price IS NULL OR v_price<0 OR v_price>9000000000000/v_qty
   THEN RAISE EXCEPTION 'Unavailable product or invalid price'; END IF;
  v_prices:=array_append(v_prices,v_price);
 END LOOP;
 INSERT INTO public.gs_orders(created_by,destination,is_motel,tourism_mode)
 VALUES(v_uid,CASE WHEN p_is_motel THEN btrim(p_destination) ELSE p_table_number::text END,p_is_motel,v_mode)
 RETURNING id INTO v_order;
 FOR v_line IN SELECT value FROM jsonb_array_elements(p_items) LOOP
  v_line_index:=v_line_index+1;
  v_id:=(v_line->>'product_id')::bigint; v_qty:=(v_line->>'quantity')::integer;
  v_price:=v_prices[v_line_index];
  INSERT INTO public.gs_order_items(order_id,product_id,quantity,unit_price_iqd)
   VALUES(v_order,v_id,v_qty,v_price);
 END LOOP;
 RETURN v_order;
END $$;
REVOKE ALL ON FUNCTION public.gs_create_cart_order(text,boolean,integer,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.gs_create_cart_order(text,boolean,integer,jsonb) TO authenticated;
COMMIT;
