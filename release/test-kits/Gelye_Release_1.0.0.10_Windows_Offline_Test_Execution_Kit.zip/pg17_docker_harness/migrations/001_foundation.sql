-- Release 1.0.0.10, corrected order foundation, STAGING ONLY
-- Target ref: snypqykxtevmgxlrivro; NEVER execute against gumudllyhzxoswmmweve.
-- NOT APPLIED. Requires security and integration approval before application.
-- Tourism Mode changes require separate Admin/Manager approval (021).
BEGIN;
DO $preflight$
BEGIN
 IF to_regclass('public.employee_profiles') IS NULL
    OR to_regclass('public.employee_section_permissions') IS NULL
    OR to_regclass('auth.users') IS NULL THEN
   RAISE EXCEPTION 'Missing employee/auth prerequisite tables';
 END IF;
 IF to_regclass('public.gs_menu_products') IS NOT NULL
    OR to_regclass('public.gs_orders') IS NOT NULL
    OR to_regclass('public.gs_order_items') IS NOT NULL THEN
   RAISE EXCEPTION 'Order foundation objects already exist: manual reconciliation required';
 END IF;
END;
$preflight$;
CREATE TABLE public.gs_menu_products (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 barcode text NOT NULL UNIQUE CHECK (length(trim(barcode)) > 0),
 name text NOT NULL CHECK (length(trim(name)) > 0),
 normal_price_iqd bigint NOT NULL CHECK (normal_price_iqd BETWEEN 0 AND 9000000000000),
 tourism_price_iqd bigint NOT NULL CHECK (tourism_price_iqd BETWEEN 0 AND 9000000000000),
 is_active boolean NOT NULL DEFAULT true,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE public.gs_orders (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 created_by uuid NOT NULL REFERENCES auth.users(id),
 destination text NOT NULL CHECK (length(trim(destination)) BETWEEN 1 AND 120),
 is_motel boolean NOT NULL,
 tourism_mode boolean NOT NULL,
 status text NOT NULL DEFAULT 'new' CHECK (status IN ('new','preparing','ready','served','cancelled')),
 created_at timestamptz NOT NULL DEFAULT now(),
 CONSTRAINT gs_motel_tourism CHECK (NOT is_motel OR tourism_mode)
);
CREATE TABLE public.gs_order_items (
 id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 order_id bigint NOT NULL REFERENCES public.gs_orders(id) ON DELETE RESTRICT,
 product_id bigint NOT NULL REFERENCES public.gs_menu_products(id),
 quantity integer NOT NULL CHECK (quantity BETWEEN 1 AND 999),
 unit_price_iqd bigint NOT NULL CHECK (unit_price_iqd BETWEEN 0 AND 9000000000000),
 line_total_iqd bigint GENERATED ALWAYS AS (quantity * unit_price_iqd) STORED
);
CREATE INDEX gs_orders_created_at_idx ON public.gs_orders(created_at DESC);
CREATE INDEX gs_order_items_order_id_idx ON public.gs_order_items(order_id);
ALTER TABLE public.gs_menu_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gs_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gs_order_items ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.gs_menu_products, public.gs_orders, public.gs_order_items FROM PUBLIC, anon, authenticated;
GRANT SELECT ON public.gs_menu_products, public.gs_orders, public.gs_order_items TO authenticated;
GRANT ALL PRIVILEGES ON public.gs_menu_products, public.gs_orders, public.gs_order_items TO service_role;
REVOKE ALL ON SEQUENCE public.gs_menu_products_id_seq, public.gs_orders_id_seq, public.gs_order_items_id_seq FROM PUBLIC,anon,authenticated;
GRANT USAGE,SELECT ON SEQUENCE public.gs_menu_products_id_seq, public.gs_orders_id_seq, public.gs_order_items_id_seq TO service_role;
-- SECURITY DEFINER functions intentionally owned by the migration owner, never by an end user.
CREATE FUNCTION public.gs_can_access(p_section text, p_action text DEFAULT 'can_view')
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $body$
 SELECT (SELECT auth.uid()) IS NOT NULL
    AND (SELECT auth.jwt() ->> 'aal') = 'aal2'
    AND EXISTS (
       SELECT 1 FROM public.employee_profiles ep
       JOIN public.employee_section_permissions perm ON perm.user_id = ep.user_id
       WHERE ep.user_id = (SELECT auth.uid()) AND ep.is_active IS TRUE
         AND perm.section_key = p_section
         AND CASE p_action
             WHEN 'can_view' THEN perm.can_view
             WHEN 'can_create' THEN perm.can_create
             WHEN 'can_edit' THEN perm.can_edit
             WHEN 'can_delete' THEN perm.can_delete
             ELSE false END IS TRUE
    );
$body$;
REVOKE ALL ON FUNCTION public.gs_can_access(text,text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.gs_can_access(text,text) TO authenticated;
CREATE POLICY gs_products_read ON public.gs_menu_products FOR SELECT TO authenticated
 USING (public.gs_can_access('menu') OR public.gs_can_access('table_orders') OR public.gs_can_access('motel_orders'));
CREATE POLICY gs_orders_read ON public.gs_orders FOR SELECT TO authenticated
 USING (public.gs_can_access(CASE WHEN is_motel THEN 'motel_orders' ELSE 'table_orders' END)
        OR public.gs_can_access('kitchen'));
CREATE POLICY gs_order_items_read ON public.gs_order_items FOR SELECT TO authenticated
 USING (EXISTS (SELECT 1 FROM public.gs_orders o WHERE o.id = order_id));
-- Legacy caller-controlled pricing RPC intentionally omitted.
-- Application uses gs_create_order_for_destination and gs_create_cart_order.
COMMIT;
