# Windows Docker Desktop: exact offline runbook

1. Install and start Docker Desktop, enable WSL 2 backend, and wait until the engine reports running. Open VS Code, then open this ZIP's extracted folder.
2. Keep the `pg17_docker_harness` directory and `Run-OfflineTests.ps1` in the same parent folder. Do not enter any Supabase URL, token or production credentials.
3. Open VS Code **Terminal → New Terminal**, select PowerShell, and run:

```powershell
Set-Location 'C:\PATH\TO\EXTRACTED\FOLDER'
docker version
docker compose -f .\pg17_docker_harness\compose.yaml config
powershell -NoProfile -ExecutionPolicy Bypass -File .\Run-OfflineTests.ps1
```

The script records `results_YYYYMMDD_HHMMSS` with `result.json`, `test_output.txt`, container logs, Compose validation, startup details, and any failure message. It exits 1 on failure and preserves the local container for investigation. Run only after reviewing the script; execution-policy bypass is scoped to this process, not a machine-wide policy change.

4. Inspect `result.json` and `test_output.txt`. A `PASS` means only that the **local mocked harness** passed, not that Supabase JWT integration, staging, or production is validated.
5. If a test fails, copy the exact first `ERROR:` and its nearby `RUNNING:` or `COMPILING:` label into the report template. Never rerun on a dirty database to try to force a pass.
6. After saving diagnostics, reset the disposable database:

```powershell
Set-Location '.\pg17_docker_harness'
docker compose down -v
Set-Location '..'
```

This deletes the **local** disposable test database only. To run a fresh test, return to step 3.

### Troubleshooting
- `docker` not recognized: install Docker Desktop, reopen VS Code.
- Cannot connect to Docker engine: start Docker Desktop and wait for readiness.
- Port 55432 already allocated: identify the conflicting local process; do not change the host binding to `0.0.0.0`.
- `ERROR: relation already exists`: stop and remove the local test container (`docker compose down -v`) before rerunning.
- `ERROR: permission denied`: preserve the SQL output and inspect role/grant assertions; do not grant blanket privileges just to pass tests.
- SQL syntax failure: record filename and line number; stop release progression.
- Concurrency timeout mismatch: preserve both runner and container logs; investigate lock ordering and test readiness, not just timeout duration.
- `RUNNING:` count is below 20: test runner aborted or fixture failed; mark overall FAIL.

**No Supabase staging or production connection is required or permitted for this runbook.**
