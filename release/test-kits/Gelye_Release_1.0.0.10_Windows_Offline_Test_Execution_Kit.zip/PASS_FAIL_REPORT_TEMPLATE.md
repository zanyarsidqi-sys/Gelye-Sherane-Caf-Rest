# Release 1.0.0.10 — offline PostgreSQL 17 test report

**Date / time:** [fill in]
**Operator:** [fill in]
**Docker Desktop version:** [from docker_version.txt]
**Container image:** postgres:17.6
**SQL package SHA256:** [fill in]
**Environment:** Windows Docker Desktop, local container only
**Supabase staging changes:** None
**Production changes:** None

| Gate | Result (PASS/FAIL/NOT RUN) | Evidence / first failure |
|---|---|---|
| Docker version and Compose config | | docker_version.txt, compose_config.txt |
| Fresh database startup | | startup.txt |
| SQL migration compilation (001→021) | | test_output.txt |
| Function owner / SECURITY DEFINER / search_path | | test_output.txt |
| Table, sequence and function grants | | test_output.txt |
| RLS policies and MFA AAL2 | | test_output.txt |
| 20 numbered behavioral cases | | test_output.txt |
| Concurrent order versus approval | | test_output.txt |
| Exit status of runner | | result.json |

**Overall:** [PASS / FAIL / NOT RUN]

**First failing command and PostgreSQL error:** [copy exact line]

**Remediation:** [describe]

**Retest evidence:** [new results folder]

**Decision:** HOLD until all required tests pass and Supabase-specific security is independently verified. Local mocks do not verify JWT signatures.
