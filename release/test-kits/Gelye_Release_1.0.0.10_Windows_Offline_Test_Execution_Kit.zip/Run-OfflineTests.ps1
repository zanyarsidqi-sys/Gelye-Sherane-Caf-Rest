param([switch]$CleanupAfter)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$project = Join-Path $here 'pg17_docker_harness'
if (!(Test-Path (Join-Path $project 'compose.yaml'))) { throw 'Missing pg17_docker_harness/compose.yaml next to this script.' }
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$logs = Join-Path $here "results_$stamp"
New-Item -ItemType Directory -Path $logs | Out-Null
$overall = 'FAIL'
$stage = 'preflight'
$code = 1
Push-Location $project
try {
    $docker = Get-Command docker -ErrorAction Stop
    & docker version *> (Join-Path $logs 'docker_version.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Docker engine unavailable; see docker_version.txt.' }
    $stage = 'compose_config'
    & docker compose config *> (Join-Path $logs 'compose_config.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Compose config failed.' }
    $stage = 'startup'
    & docker compose up -d --wait *> (Join-Path $logs 'startup.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Container startup failed.' }
    $stage = 'sql_tests'
    & docker compose exec -T postgres sh /harness/sql/10_compile.sh *> (Join-Path $logs 'test_output.txt')
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw "Test runner failed (exit $code)." }
    $overall = 'PASS'
}
catch {
    $_.Exception.Message | Out-File (Join-Path $logs 'failure.txt') -Encoding utf8
    Write-Warning $_.Exception.Message
}
finally {
    & docker compose ps -a *> (Join-Path $logs 'container_status.txt')
    & docker compose logs --no-color --timestamps *> (Join-Path $logs 'container_logs.txt')
    $record = [ordered]@{
        date_utc=(Get-Date).ToUniversalTime().ToString('o')
        result=$overall
        failed_stage=if ($overall -eq 'PASS') { $null } else { $stage }
        sql_runner_exit_code=$code
        local_only=$true
        staging_touched=$false
        production_touched=$false
        logs_folder=$logs
    }
    $record | ConvertTo-Json | Set-Content (Join-Path $logs 'result.json') -Encoding utf8
    if ($CleanupAfter) {
        & docker compose down -v *> (Join-Path $logs 'cleanup.txt')
    } else {
        'Container retained for local diagnosis. To remove it later: docker compose down -v' | Set-Content (Join-Path $logs 'cleanup_instructions.txt')
    }
    Pop-Location
}
Write-Host "Result: $overall"
Write-Host "Logs: $logs"
if ($overall -ne 'PASS') { exit 1 }
